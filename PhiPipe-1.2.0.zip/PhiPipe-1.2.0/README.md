PhiPipe is a processing pipeline for structual, functional and diffusion MRI brain images, which was developed at [Psychlogical Health and Imaging Group](http://phi-group.top)

More details could be found in the manual.
